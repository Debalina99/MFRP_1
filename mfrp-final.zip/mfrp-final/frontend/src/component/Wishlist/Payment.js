import React, { Fragment, useEffect, useRef } from "react";
import CheckoutSteps from "../Wishlist/CheckoutSteps";
import { useSelector, useDispatch } from "react-redux";
import MetaData from "../layout/MetaData";
import { Typography } from "@material-ui/core";
import { useAlert } from "react-alert";
import {
  CardNumberElement,
  CardCvcElement,
  CardExpiryElement,
  useStripe,
  useElements,
} from "@stripe/react-stripe-js";

import axios from "axios";
import "./payment.css";
import CreditCardIcon from "@material-ui/icons/CreditCard";
import EventIcon from "@material-ui/icons/Event";
import VpnKeyIcon from "@material-ui/icons/VpnKey";
import { createRequest, clearErrors } from "../../actions/requestAction";

const Payment = ({ history }) => {
  const requestInfo = JSON.parse(sessionStorage.getItem("requestInfo"));

  const dispatch = useDispatch();
  const alert = useAlert();
  const stripe = useStripe();
  const elements = useElements();
  const payBtn = useRef(null);

  const { shippingInfo, wishlistItems } = useSelector((state) => state.wishlist);
  const { user } = useSelector((state) => state.user);
  const { error } = useSelector((state) => state.newRequest);

  const paymentData = {
    amount: Math.round(requestInfo.totalPrice * 100),
  };

  const request = {
    shippingInfo,
    requestItems: wishlistItems,
    itemsPrice: requestInfo.subtotal,
    taxPrice: requestInfo.tax,
    shippingPrice: requestInfo.shippingCharges,
    totalPrice: requestInfo.totalPrice,
  };

  const submitHandler = async (e) => {
    e.preventDefault();

    payBtn.current.disabled = true;

    try {
      // const config = {
      //   headers: {
      //     "Content-Type": "application/json",
      //   },
      // };
      // const { data } = await axios.post(
      //   "/api/v1/payment/process",
      //   paymentData,
      //   config
      // );

      // const client_secret = data.client_secret;

      // if (!stripe || !elements) return;

      // const result = await stripe.confirmCardPayment(client_secret, {
      //   payment_method: {
      //     card: elements.getElement(CardNumberElement),
      //     billing_details: {
      //       name: user.name,
      //       email: user.email,
            
            
      //     },
      //   },
      // });

      // if (result.error) {
      //   payBtn.current.disabled = false;

      //   alert.error(result.error.message);
      // } else {
      //   if (result.paymentIntent.status === "succeeded") {
      //     request.paymentInfo = {
      //       id: result.paymentIntent.id,
      //       status: result.paymentIntent.status,
      //     };

          dispatch(createRequest(request));

          history.push("/success");
        } 
    //     else {
    //       alert.error("Something is wrong!");
    //     }
    //   }
    // } 
    catch (error) {
      payBtn.current.disabled = false;
      alert.error(error.response.data.message);
    }
  }

  useEffect(() => {
    if (error) {
      alert.error(error);
      dispatch(clearErrors());
    }
  }, [dispatch, error, alert]);

  return (
    <Fragment>
      <MetaData title="Payment" />
      <CheckoutSteps activeStep={2} />
      <div id="scroll-container">
        <p id="scroll-text"><strong id="note">Note: </strong>Late fee of Rs. 5/- per day per book would be charged from all the borrowers who retain book(s) beyond the due date. Director General/ Librarian may exempt the late fee depending upon the circumstances of delay.</p>
      </div>
      <div className="paymentContainer">
        
        <form className="paymentForm" onSubmit={(e) => submitHandler(e)}>
          <h1>Are you sure?</h1><br></br>
          {/* <div>
            <CreditCardIcon />
            <CardNumberElement className="paymentInput" />
          </div>
          <div>
            <EventIcon />
            <CardExpiryElement className="paymentInput" />
          </div>
          <div>
            <VpnKeyIcon />
            <CardCvcElement className="paymentInput" />
          </div> */}

          {/* <div>
            <input type="number" className="paymentInput">Optional Mobile number</input>
          </div>
          <div>
            <input type="number" className="paymentInput">Address</input>
          </div> */}

          <input
            type="submit"
            // value={`Pay - ₹${requestInfo && requestInfo.totalPrice}`}
            value={'Issue'}
            ref={payBtn}
            className="paymentFormBtn"
          />
        </form>
      </div>
    </Fragment>
  );
};

export default Payment;
